"use client";

import { useState } from "react";
import { MdPhone, MdEmail } from "react-icons/md";
import { FaWhatsapp } from "react-icons/fa";
import { AiOutlineHeart } from "react-icons/ai";
import { MdOutlineMenu } from "react-icons/md";
import { IoIosArrowUp, IoIosArrowDown } from "react-icons/io";

export interface LabelConfig {
  key: string;
  label: string;
}

interface LeadsSectionProps<T extends Record<string, any>> {
  leads: T[];
  labelLeads: LabelConfig[];
}

export default function LeadsSection<T extends Record<string, any>>({
  leads,
  labelLeads,
}: LeadsSectionProps<T>) {
  const [toggleSearchDropdown, setToggleSearchDropdown] = useState(false);

  return (
    <>
      {/* HEADER */}
      {/* <header className="bg-table text-white p-4 flex items-center">
        <MdOutlineMenu className="text-xl" />
        <span className="ml-4 font-semibold text-xl">Make My Leads</span>
      </header> */}

      {/* ADVANCED SEARCH */}
      {/* <div
        onClick={() => setToggleSearchDropdown(!toggleSearchDropdown)}
        className="bg-table px-3 py-1.5 w-fit rounded-2xl my-4 ml-5 flex items-center cursor-pointer"
      >
        <button className="text-white text-xs font-semibold">ADVANCED SEARCH</button>
        <button className="p-2 text-white">
          {toggleSearchDropdown ? <IoIosArrowUp /> : <IoIosArrowDown />}
        </button>
      </div> */}

      {/* LEAD CARDS */}
      <div className="px-4 pb-4">
        {leads.map((lead, index) => (
          <div key={index} className="bg-white shadow-md rounded-2xl overflow-hidden border mb-5">
            <div className="bg-table h-2"></div>

            <div className="flex justify-between items-start p-4">
              <div>
                {labelLeads.map((item, j) => (
                  <div key={j} className="mb-2">
                    <span className="font-semibold text-black text-lg">{item.label}</span>
                    <span className="mx-2">-</span>
                    <span className="text-gray-700 text-lg">
                      {String(lead[item.key])}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-2 bg-gray-100 rounded-full shadow">
                <AiOutlineHeart size={20} className="text-indigo-500" />
              </div>
            </div>

            <div className="bg-table p-3 flex justify-between">
              <button className="text-white border border-white px-3 text-sm py-1 rounded-full">
                FOLLOW UP
              </button>

              <div className="flex items-center gap-5">
                <a href={`tel:${lead["number"] ?? ""}`}>
                  <MdPhone size={20} className="text-white" />
                </a>
                <MdEmail size={20} className="text-white" />
                <a href={`https://wa.me/${lead["number"] ?? ""}`} target="_blank">
                  <FaWhatsapp size={20} className="text-white" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
