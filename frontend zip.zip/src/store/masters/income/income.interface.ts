export interface incomeAllDataInterface {
    Name:string;
    Status:string;
}

export interface incomeGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface incomeDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }