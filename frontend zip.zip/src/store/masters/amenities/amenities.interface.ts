export interface amenitiesAllDataInterface {
    Name:string;
    Status:string;
}

export interface amenitiesGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface DeleteDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }