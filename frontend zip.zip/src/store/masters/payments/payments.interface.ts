export interface paymentsAllDataInterface {
    Name:string;
    Status:string;
}

export interface paymentsGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface paymentsDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }