export interface referencesAllDataInterface {
    Name:string;
    Status:string;
}

export interface referencesGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface referencesDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }