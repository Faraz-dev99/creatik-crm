export interface contactcampaignAllDataInterface {
    Name:string;
    Status:string;
}

export interface contactcampaignGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface contactcampaignDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }